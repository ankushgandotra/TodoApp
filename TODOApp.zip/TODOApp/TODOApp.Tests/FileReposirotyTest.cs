﻿using NUnit.Framework;
using System.IO;
using System.Threading.Tasks;
using TODOApp.Repository;

namespace TODOApp.Tests
{
    public class FileReposirotyTest
    {
        private FileRepository fileRepository;

        [SetUp]
        public void Setup()
        {
            fileRepository = new FileRepository();

            //create txt file if not exists
            if (!File.Exists("todo.txt"))
            {
                File.Create("todo.txt");
            }
        }

        [Test]
        public void ReadFileTest()
        {
            var result = fileRepository.ReadFile();
            Assert.IsInstanceOf<Task<string[]>>(result);
        }
        
    }
}
