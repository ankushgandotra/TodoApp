﻿using System.Threading.Tasks;

namespace TODOApp.Interfaces
{
    public interface IFileRepository
    {
        Task<string[]> ReadFile();
        Task UpdateFile(string task);
    }
}
