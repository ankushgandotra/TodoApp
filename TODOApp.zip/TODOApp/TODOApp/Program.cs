﻿using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.Extensions.DependencyInjection;
using TODOApp.Interfaces;
using TODOApp.Repository;

namespace TODOApp
{
    public class Program
    {
        private static IServiceProvider serviceProvider;
        private static IFileRepository service;
        static async Task Main(string[] args)
        {
            // load services implementation
            RegisterServices();
            service = serviceProvider.GetService<IFileRepository>();
            try
            {
                //create txt file if not exists
                if (!File.Exists("todo.txt"))
                {
                    File.Create("todo.txt");
                }
                //shoq menu available to user
                await ShowForm();
            }
            catch (Exception ex)
            {
                //exception handling
            }
        }

        private static void RegisterServices()
        {
            var collection = new ServiceCollection();
            collection.AddScoped<IFileRepository, FileRepository>();
            serviceProvider = collection.BuildServiceProvider();
        }

        private static async Task ShowForm()
        {
            Console.WriteLine("Please select one of the following options - \nPress 1 to see Todo list \nPress 2 to add a new Todo item" +
                "\nPress Escape to go back to main menu");

            ConsoleKey readKey = Console.ReadKey(true).Key;
            // show todo list
            if (readKey == ConsoleKey.D1 || readKey == ConsoleKey.NumPad1)
            {
                //show todo list
                await ShowTodo();
            }
            // add new task
            if (readKey == ConsoleKey.D2 || readKey == ConsoleKey.NumPad2)
            {
                await GetTitle();
            }
            else
            {
                Console.Clear();
                await ShowForm();
            }
        }

        private static async Task GetTitle()
        {
            Console.WriteLine("\nEnter the To do item title and press Enter." + "\n" + "Press Escape to go back to main menu");
            ConsoleKey readKey = Console.ReadKey(true).Key;
            if (readKey == ConsoleKey.Escape)
            {
                Console.Clear();
                await ShowForm();
            }
            string todoName = Console.ReadLine().Trim();
            if (String.IsNullOrEmpty(todoName))
            {
                Console.WriteLine("Todo title cannot be blank.");
                await GetTitle();
            }
            else
            {
                await GetDateInputandSave(todoName);
            }
        }

        private static async Task GetDateInputandSave(string todo)
        {
            Console.WriteLine("Enter the To do item target date time (format- DD MMM YYYY hh:mm tt) and press Enter."+"\n"+ "Press Escape to go back to main menu");
            ConsoleKey readKey = Console.ReadKey(true).Key;
            // show task list
            if (readKey == ConsoleKey.Escape)
            {
                Console.Clear();
                await ShowForm();
            }
            string datetime = Console.ReadLine().Trim();
            try
            {
                DateTime targetdate = DateTime.Parse(datetime);
                await SaveTodo(todo, targetdate.ToString("dd MMM yyyy hh:mm tt"));
            }
            catch (FormatException)
            {
               Console.WriteLine("Entered target date time is not in correct format.");
               await GetDateInputandSave(todo);
            }
        }

        private static async Task SaveTodo(string todo, string date)
        {
            await service.UpdateFile(todo + "\t" + date);
            Console.WriteLine("Todo item added successfully.");
            await ShowForm();
        }

        private static async Task ShowTodo()
        {
            string[] tasks = await service.ReadFile();
            Console.WriteLine("\nFollowing is the todo list-");
            foreach (string task in tasks)
            {
                Console.WriteLine(task);
            }
            Console.WriteLine("\n");
            await ShowForm();
        }

    }
}
