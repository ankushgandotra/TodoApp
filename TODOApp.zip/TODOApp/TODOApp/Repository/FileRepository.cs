﻿using System.IO;
using System.Threading.Tasks;
using TODOApp.Interfaces;

namespace TODOApp.Repository
{
   public class FileRepository : IFileRepository
    {
        public async Task<string[]> ReadFile()
        {
            return await File.ReadAllLinesAsync(@"todo.txt");
        }

        public async Task UpdateFile(string task)
        {
            await File.AppendAllTextAsync(@"todo.txt", "\n" + task);
        }
    }
}